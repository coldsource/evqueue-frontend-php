#!/usr/bin/php
<?php

echo "sms sent!\n";

?>