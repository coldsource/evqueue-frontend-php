<?php

class NotificationParameters {
	
	public static function check_parameters ($parameters) {
		return true;
	}
	
	public static function serialise ($parameters) {
		return json_encode($parameters['number']);  // several phone numbers
	}
	
	public static function deserialise_to_xml ($string) {
		$xml = '<numbers>';
		$numbers = json_decode($string,true);
		if (is_array($numbers))
			foreach ($numbers as $number) {
				$xml .= '<number>'.htmlspecialchars($number).'</number>';
			}
		return "$xml</numbers>";
	}
	
}

?>